//
//  FruitsView.swift
//  FruitApp
//
//  Created by user272495 on 1/22/25.
//

import SwiftUI

struct FruitsView: View {
    
    let fruits = ["Apple", "Orange", "Banana"]
    var body: some View {
        HStack {
            ForEach(fruits, id: \.self ) { fruit in
                Button (action: {}){
                    Text(fruit)

                }
            }
        }
        
    }
}

#Preview {
    FruitsView()
}
