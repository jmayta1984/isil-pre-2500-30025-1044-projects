//
//  ContentView.swift
//  FruitApp
//
//  Created by user272495 on 1/22/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            NavigationLink(destination: {
                
            }) {
                Text("Choose")
            }
        }
      
    }
}

#Preview {
    ContentView()
}
