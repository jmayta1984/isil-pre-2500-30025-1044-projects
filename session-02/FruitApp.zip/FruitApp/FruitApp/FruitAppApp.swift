//
//  FruitAppApp.swift
//  FruitApp
//
//  Created by user272495 on 1/22/25.
//

import SwiftUI

@main
struct FruitAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
